﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lblNome_Click(object sender, EventArgs e)
        {

        }

        private void txtAliquotaINSS_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblSalarioFamilia_Click(object sender, EventArgs e)
        {

        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            lblDados.Visible = true;

            double SalarioBruto = 0;
            double NumeroFilhos = 0;
            double DescontoINSS = 0;
            double DescontoIRRF = 0;
            double SalarioFamilia = 0;
            double SalarioLiquido = 0;

            if (txtNome.Text == String.Empty)
            {
                MessageBox.Show("Campo vazio! Insira o nome do funcionário!");
            }

            else
            {
                if (!double.TryParse(txtSalarioBruto), out SalarioBruto ||
                !double.TryParse(nupdFilhos), out NumeroFilhos))
                MessageBox.Show("Os campos Salário Bruto e Número de Filhos devem ter números válidos do tipo inteiro");
               
                else
                {
                    if (SalarioBruto <= 0)
                        MessageBox.Show("Salário Bruto deve ser maior que 0!");

                    else
                    {
                        if (SalarioBruto <= 800.47)
                        {
                            mskbxAliquotaINSS.Text = "7,65%";
                            DescontoINSS = 0.0765 * SalarioBruto;
                        }

                        else
                        {
                            if (SalarioBruto <= 1050)
                            {
                                mskbxAliquotaINSS.Text = "8,65%";
                                DescontoINSS = ((8.65 / 100) * SalarioBruto);
                            }

                            else
                            {
                                if (SalarioBruto <= 1400.77)
                                {
                                    mskbxAliquotaINSS.Text = "9,00%";
                                    DescontoINSS = ((9.00 / 100) * SalarioBruto);
                                }

                                else
                                {
                                    if (SalarioBruto <= 2801.56)
                                    {
                                        mskbxAliquotaINSS.Text = "11,00%";
                                        DescontoINSS = ((11.00 / 100) * SalarioBruto);
                                    }

                                    else
                                    {
                                        mskbxAliquotaINSS.Text = "308,17 (teto)";
                                        DescontoINSS = 308.17;
                                    }
                                }
                            }
                        }

                        if (SalarioBruto <= 1257.12)
                        {
                            mskbxAliquotaIRRF.Text = "Isento do Imposto";
                        }
                        else
                        {
                            if (SalarioBruto <= 2512.08)
                            {
                                mskbxAliquotaIRRF.Text = "15,00%";
                                DescontoIRRF = ((15.00 / 100) * SalarioBruto);
                            }
                            else
                            {
                                mskbxAliquotaIRRF.Text = "27,5%";
                                DescontoIRRF = ((27.5 / 100) * SalarioBruto);
                            }
                        }

                        if (SalarioBruto <= 435.52)
                        {
                            SalarioFamilia = NumeroFilhos * 22.33;
                        }
                        else
                        {
                            if (SalarioBruto <= 654.61)
                            {
                                SalarioFamilia = NumeroFilhos * 15.74;
                            }
                            else
                            {
                                mskbxSalarioFamilia.Text = "Sem direito ao benefício";
                            }
                        }


                        SalarioLiquido = (SalarioBruto - DescontoINSS - DescontoIRRF + SalarioFamilia);

                        mskbxSalarioFamilia.Text = Convert.ToString(SalarioFamilia) + " R$";
                        mskbxDescontoINSS.Text = Convert.ToString(DescontoINSS) + " R$";
                        mskbxDescontoIRRF.Text = Convert.ToString(DescontoIRRF) + " R$";
                        mskbxSalarioLiquido.Text = Convert.ToString(SalarioLiquido) + " R$";
                    }
                }

            }

            lblDados.Text = "Os descontos do salário" + (rbtnFeminino.Checked == true ? "da Sra." : "do Sr." + txtNome.Text
            + "que é" + (rbtnCasado.Checked ? "Casado(a)" : "Solteiro(a)")
            + "e que tem" + Convert.ToString(NumeroFilhos) + " filho(s) são:";
        }

    }
}
