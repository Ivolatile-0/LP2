﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalarioBruto = new System.Windows.Forms.TextBox();
            this.lblIRRF = new System.Windows.Forms.Label();
            this.lblSalarioFamilia = new System.Windows.Forms.Label();
            this.lblSalarioLiquido = new System.Windows.Forms.Label();
            this.lblDescontoINSS = new System.Windows.Forms.Label();
            this.lblDescontoIRRF = new System.Windows.Forms.Label();
            this.nupdFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskbxAliquotaINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskbxAliquotaIRRF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskbxSalarioLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoIRRF = new System.Windows.Forms.MaskedTextBox();
            this.mskbxDescontoINSS = new System.Windows.Forms.MaskedTextBox();
            this.gpbxSexo = new System.Windows.Forms.GroupBox();
            this.rbtnMasculino = new System.Windows.Forms.RadioButton();
            this.rbtnFeminino = new System.Windows.Forms.RadioButton();
            this.gpbxEstadoCivil = new System.Windows.Forms.GroupBox();
            this.rbtnCasado = new System.Windows.Forms.RadioButton();
            this.lblDados = new System.Windows.Forms.Label();
            this.btnVerificar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).BeginInit();
            this.gpbxSexo.SuspendLayout();
            this.gpbxEstadoCivil.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(51, 109);
            this.lblNome.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(187, 27);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome do Funcionário";
            this.lblNome.Click += new System.EventHandler(this.lblNome_Click);
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalario.Location = new System.Drawing.Point(51, 191);
            this.lblSalario.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(118, 27);
            this.lblSalario.TabIndex = 2;
            this.lblSalario.Text = "Salário Bruto";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilhos.Location = new System.Drawing.Point(51, 258);
            this.lblFilhos.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(157, 27);
            this.lblFilhos.TabIndex = 3;
            this.lblFilhos.Text = "Número de Filhos";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblINSS.Location = new System.Drawing.Point(51, 497);
            this.lblINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(127, 27);
            this.lblINSS.TabIndex = 5;
            this.lblINSS.Text = "Alíquota INSS";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(314, 112);
            this.txtNome.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(148, 26);
            this.txtNome.TabIndex = 6;
            // 
            // txtSalarioBruto
            // 
            this.txtSalarioBruto.Location = new System.Drawing.Point(314, 191);
            this.txtSalarioBruto.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txtSalarioBruto.Name = "txtSalarioBruto";
            this.txtSalarioBruto.Size = new System.Drawing.Size(148, 26);
            this.txtSalarioBruto.TabIndex = 7;
            // 
            // lblIRRF
            // 
            this.lblIRRF.AutoSize = true;
            this.lblIRRF.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIRRF.Location = new System.Drawing.Point(54, 563);
            this.lblIRRF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblIRRF.Name = "lblIRRF";
            this.lblIRRF.Size = new System.Drawing.Size(127, 27);
            this.lblIRRF.TabIndex = 9;
            this.lblIRRF.Text = "Alíquota IRRF";
            // 
            // lblSalarioFamilia
            // 
            this.lblSalarioFamilia.AutoSize = true;
            this.lblSalarioFamilia.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioFamilia.Location = new System.Drawing.Point(51, 637);
            this.lblSalarioFamilia.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioFamilia.Name = "lblSalarioFamilia";
            this.lblSalarioFamilia.Size = new System.Drawing.Size(134, 27);
            this.lblSalarioFamilia.TabIndex = 10;
            this.lblSalarioFamilia.Text = "Salário Família";
            this.lblSalarioFamilia.Click += new System.EventHandler(this.lblSalarioFamilia_Click);
            // 
            // lblSalarioLiquido
            // 
            this.lblSalarioLiquido.AutoSize = true;
            this.lblSalarioLiquido.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSalarioLiquido.Location = new System.Drawing.Point(51, 711);
            this.lblSalarioLiquido.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblSalarioLiquido.Name = "lblSalarioLiquido";
            this.lblSalarioLiquido.Size = new System.Drawing.Size(132, 27);
            this.lblSalarioLiquido.TabIndex = 11;
            this.lblSalarioLiquido.Text = "Salário Líquido";
            // 
            // lblDescontoINSS
            // 
            this.lblDescontoINSS.AutoSize = true;
            this.lblDescontoINSS.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoINSS.Location = new System.Drawing.Point(687, 497);
            this.lblDescontoINSS.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoINSS.Name = "lblDescontoINSS";
            this.lblDescontoINSS.Size = new System.Drawing.Size(138, 27);
            this.lblDescontoINSS.TabIndex = 12;
            this.lblDescontoINSS.Text = "Desconto INSS";
            // 
            // lblDescontoIRRF
            // 
            this.lblDescontoIRRF.AutoSize = true;
            this.lblDescontoIRRF.Font = new System.Drawing.Font("Arial Narrow", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDescontoIRRF.Location = new System.Drawing.Point(686, 560);
            this.lblDescontoIRRF.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDescontoIRRF.Name = "lblDescontoIRRF";
            this.lblDescontoIRRF.Size = new System.Drawing.Size(138, 27);
            this.lblDescontoIRRF.TabIndex = 13;
            this.lblDescontoIRRF.Text = "Desconto IRRF";
            // 
            // nupdFilhos
            // 
            this.nupdFilhos.Location = new System.Drawing.Point(314, 258);
            this.nupdFilhos.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nupdFilhos.Name = "nupdFilhos";
            this.nupdFilhos.Size = new System.Drawing.Size(180, 26);
            this.nupdFilhos.TabIndex = 20;
            // 
            // mskbxAliquotaINSS
            // 
            this.mskbxAliquotaINSS.Enabled = false;
            this.mskbxAliquotaINSS.Location = new System.Drawing.Point(314, 500);
            this.mskbxAliquotaINSS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mskbxAliquotaINSS.Name = "mskbxAliquotaINSS";
            this.mskbxAliquotaINSS.Size = new System.Drawing.Size(148, 26);
            this.mskbxAliquotaINSS.TabIndex = 21;
            // 
            // mskbxAliquotaIRRF
            // 
            this.mskbxAliquotaIRRF.Enabled = false;
            this.mskbxAliquotaIRRF.Location = new System.Drawing.Point(314, 563);
            this.mskbxAliquotaIRRF.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mskbxAliquotaIRRF.Name = "mskbxAliquotaIRRF";
            this.mskbxAliquotaIRRF.Size = new System.Drawing.Size(148, 26);
            this.mskbxAliquotaIRRF.TabIndex = 22;
            // 
            // mskbxSalarioFamilia
            // 
            this.mskbxSalarioFamilia.Enabled = false;
            this.mskbxSalarioFamilia.Location = new System.Drawing.Point(314, 640);
            this.mskbxSalarioFamilia.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mskbxSalarioFamilia.Name = "mskbxSalarioFamilia";
            this.mskbxSalarioFamilia.Size = new System.Drawing.Size(148, 26);
            this.mskbxSalarioFamilia.TabIndex = 23;
            // 
            // mskbxSalarioLiquido
            // 
            this.mskbxSalarioLiquido.Enabled = false;
            this.mskbxSalarioLiquido.Location = new System.Drawing.Point(314, 711);
            this.mskbxSalarioLiquido.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mskbxSalarioLiquido.Name = "mskbxSalarioLiquido";
            this.mskbxSalarioLiquido.Size = new System.Drawing.Size(148, 26);
            this.mskbxSalarioLiquido.TabIndex = 24;
            // 
            // mskbxDescontoIRRF
            // 
            this.mskbxDescontoIRRF.Enabled = false;
            this.mskbxDescontoIRRF.Location = new System.Drawing.Point(876, 560);
            this.mskbxDescontoIRRF.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mskbxDescontoIRRF.Name = "mskbxDescontoIRRF";
            this.mskbxDescontoIRRF.Size = new System.Drawing.Size(148, 26);
            this.mskbxDescontoIRRF.TabIndex = 25;
            // 
            // mskbxDescontoINSS
            // 
            this.mskbxDescontoINSS.Enabled = false;
            this.mskbxDescontoINSS.Location = new System.Drawing.Point(876, 500);
            this.mskbxDescontoINSS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mskbxDescontoINSS.Name = "mskbxDescontoINSS";
            this.mskbxDescontoINSS.Size = new System.Drawing.Size(148, 26);
            this.mskbxDescontoINSS.TabIndex = 26;
            // 
            // gpbxSexo
            // 
            this.gpbxSexo.Controls.Add(this.rbtnMasculino);
            this.gpbxSexo.Controls.Add(this.rbtnFeminino);
            this.gpbxSexo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbxSexo.Location = new System.Drawing.Point(832, 68);
            this.gpbxSexo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbxSexo.Name = "gpbxSexo";
            this.gpbxSexo.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbxSexo.Size = new System.Drawing.Size(300, 154);
            this.gpbxSexo.TabIndex = 27;
            this.gpbxSexo.TabStop = false;
            this.gpbxSexo.Text = "Sexo";
            // 
            // rbtnMasculino
            // 
            this.rbtnMasculino.AutoSize = true;
            this.rbtnMasculino.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.rbtnMasculino.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnMasculino.Location = new System.Drawing.Point(27, 95);
            this.rbtnMasculino.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtnMasculino.Name = "rbtnMasculino";
            this.rbtnMasculino.Size = new System.Drawing.Size(147, 33);
            this.rbtnMasculino.TabIndex = 1;
            this.rbtnMasculino.TabStop = true;
            this.rbtnMasculino.Text = "Masculino";
            this.rbtnMasculino.UseVisualStyleBackColor = true;
            // 
            // rbtnFeminino
            // 
            this.rbtnFeminino.AutoSize = true;
            this.rbtnFeminino.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rbtnFeminino.Location = new System.Drawing.Point(27, 43);
            this.rbtnFeminino.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtnFeminino.Name = "rbtnFeminino";
            this.rbtnFeminino.Size = new System.Drawing.Size(139, 33);
            this.rbtnFeminino.TabIndex = 0;
            this.rbtnFeminino.TabStop = true;
            this.rbtnFeminino.Text = "Feminino";
            this.rbtnFeminino.UseVisualStyleBackColor = true;
            // 
            // gpbxEstadoCivil
            // 
            this.gpbxEstadoCivil.Controls.Add(this.rbtnCasado);
            this.gpbxEstadoCivil.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gpbxEstadoCivil.Location = new System.Drawing.Point(832, 231);
            this.gpbxEstadoCivil.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbxEstadoCivil.Name = "gpbxEstadoCivil";
            this.gpbxEstadoCivil.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.gpbxEstadoCivil.Size = new System.Drawing.Size(300, 156);
            this.gpbxEstadoCivil.TabIndex = 29;
            this.gpbxEstadoCivil.TabStop = false;
            this.gpbxEstadoCivil.Text = "Estado Civil";
            // 
            // rbtnCasado
            // 
            this.rbtnCasado.AutoSize = true;
            this.rbtnCasado.Location = new System.Drawing.Point(36, 49);
            this.rbtnCasado.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.rbtnCasado.Name = "rbtnCasado";
            this.rbtnCasado.Size = new System.Drawing.Size(121, 33);
            this.rbtnCasado.TabIndex = 2;
            this.rbtnCasado.TabStop = true;
            this.rbtnCasado.Text = "Casado";
            this.rbtnCasado.UseVisualStyleBackColor = true;
            // 
            // lblDados
            // 
            this.lblDados.AutoSize = true;
            this.lblDados.Location = new System.Drawing.Point(57, 432);
            this.lblDados.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDados.Name = "lblDados";
            this.lblDados.Size = new System.Drawing.Size(56, 20);
            this.lblDados.TabIndex = 30;
            this.lblDados.Text = "Dados";
            // 
            // btnVerificar
            // 
            this.btnVerificar.Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnVerificar.Location = new System.Drawing.Point(238, 311);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(382, 76);
            this.btnVerificar.TabIndex = 31;
            this.btnVerificar.Text = "Verificar Descontos";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.btnVerificar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1512, 1050);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.lblDados);
            this.Controls.Add(this.gpbxEstadoCivil);
            this.Controls.Add(this.gpbxSexo);
            this.Controls.Add(this.mskbxDescontoINSS);
            this.Controls.Add(this.mskbxDescontoIRRF);
            this.Controls.Add(this.mskbxSalarioLiquido);
            this.Controls.Add(this.mskbxSalarioFamilia);
            this.Controls.Add(this.mskbxAliquotaIRRF);
            this.Controls.Add(this.mskbxAliquotaINSS);
            this.Controls.Add(this.nupdFilhos);
            this.Controls.Add(this.lblDescontoIRRF);
            this.Controls.Add(this.lblDescontoINSS);
            this.Controls.Add(this.lblSalarioLiquido);
            this.Controls.Add(this.lblSalarioFamilia);
            this.Controls.Add(this.lblIRRF);
            this.Controls.Add(this.txtSalarioBruto);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Cálculo de Salário";
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).EndInit();
            this.gpbxSexo.ResumeLayout(false);
            this.gpbxSexo.PerformLayout();
            this.gpbxEstadoCivil.ResumeLayout(false);
            this.gpbxEstadoCivil.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalarioBruto;
        private System.Windows.Forms.Label lblIRRF;
        private System.Windows.Forms.Label lblSalarioFamilia;
        private System.Windows.Forms.Label lblSalarioLiquido;
        private System.Windows.Forms.Label lblDescontoINSS;
        private System.Windows.Forms.Label lblDescontoIRRF;
        private System.Windows.Forms.NumericUpDown nupdFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxAliquotaINSS;
        private System.Windows.Forms.MaskedTextBox mskbxAliquotaIRRF;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioFamilia;
        private System.Windows.Forms.MaskedTextBox mskbxSalarioLiquido;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoIRRF;
        private System.Windows.Forms.MaskedTextBox mskbxDescontoINSS;
        private System.Windows.Forms.GroupBox gpbxSexo;
        private System.Windows.Forms.RadioButton rbtnMasculino;
        private System.Windows.Forms.RadioButton rbtnFeminino;
        private System.Windows.Forms.GroupBox gpbxEstadoCivil;
        private System.Windows.Forms.RadioButton rbtnCasado;
        private System.Windows.Forms.Label lblDados;
        private System.Windows.Forms.Button btnVerificar;
    }
}

