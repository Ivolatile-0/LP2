﻿namespace Calculadora
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.lblOperacao = new System.Windows.Forms.Label();
            this.btnNumero7 = new System.Windows.Forms.Button();
            this.btnNumero8 = new System.Windows.Forms.Button();
            this.btnNumero9 = new System.Windows.Forms.Button();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnExcluir = new System.Windows.Forms.Button();
            this.btnSubtracao = new System.Windows.Forms.Button();
            this.btnNumero6 = new System.Windows.Forms.Button();
            this.btnNumero5 = new System.Windows.Forms.Button();
            this.btnNumero4 = new System.Windows.Forms.Button();
            this.btnResultado = new System.Windows.Forms.Button();
            this.btnMultiplicacao = new System.Windows.Forms.Button();
            this.btnNumero3 = new System.Windows.Forms.Button();
            this.btnNumero2 = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnDivisao = new System.Windows.Forms.Button();
            this.btnPonto = new System.Windows.Forms.Button();
            this.btnNumero0 = new System.Windows.Forms.Button();
            this.btnNumero1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtResultado
            // 
            this.txtResultado.Location = new System.Drawing.Point(32, 47);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(677, 31);
            this.txtResultado.TabIndex = 0;
            this.txtResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // lblOperacao
            // 
            this.lblOperacao.AutoSize = true;
            this.lblOperacao.BackColor = System.Drawing.Color.Transparent;
            this.lblOperacao.Location = new System.Drawing.Point(32, 47);
            this.lblOperacao.Name = "lblOperacao";
            this.lblOperacao.Size = new System.Drawing.Size(0, 25);
            this.lblOperacao.TabIndex = 1;
            // 
            // btnNumero7
            // 
            this.btnNumero7.Location = new System.Drawing.Point(32, 108);
            this.btnNumero7.Name = "btnNumero7";
            this.btnNumero7.Size = new System.Drawing.Size(113, 34);
            this.btnNumero7.TabIndex = 2;
            this.btnNumero7.Text = "7";
            this.btnNumero7.UseVisualStyleBackColor = true;
            this.btnNumero7.Click += new System.EventHandler(this.btnNumero7_Click);
            // 
            // btnNumero8
            // 
            this.btnNumero8.Location = new System.Drawing.Point(176, 108);
            this.btnNumero8.Name = "btnNumero8";
            this.btnNumero8.Size = new System.Drawing.Size(112, 34);
            this.btnNumero8.TabIndex = 3;
            this.btnNumero8.Text = "8";
            this.btnNumero8.UseVisualStyleBackColor = true;
            this.btnNumero8.Click += new System.EventHandler(this.btnNumero8_Click);
            // 
            // btnNumero9
            // 
            this.btnNumero9.Location = new System.Drawing.Point(320, 108);
            this.btnNumero9.Name = "btnNumero9";
            this.btnNumero9.Size = new System.Drawing.Size(112, 34);
            this.btnNumero9.TabIndex = 4;
            this.btnNumero9.Text = "9";
            this.btnNumero9.UseVisualStyleBackColor = true;
            this.btnNumero9.Click += new System.EventHandler(this.btnNumero9_Click);
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(458, 108);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(112, 34);
            this.btnSoma.TabIndex = 5;
            this.btnSoma.Text = "+";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(597, 108);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(112, 34);
            this.btnLimpar.TabIndex = 6;
            this.btnLimpar.Text = "Clear";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // btnExcluir
            // 
            this.btnExcluir.Location = new System.Drawing.Point(597, 164);
            this.btnExcluir.Name = "btnExcluir";
            this.btnExcluir.Size = new System.Drawing.Size(112, 34);
            this.btnExcluir.TabIndex = 11;
            this.btnExcluir.Text = "Delete";
            this.btnExcluir.UseVisualStyleBackColor = true;
            this.btnExcluir.Click += new System.EventHandler(this.btnExcluir_Click);
            // 
            // btnSubtracao
            // 
            this.btnSubtracao.Location = new System.Drawing.Point(458, 164);
            this.btnSubtracao.Name = "btnSubtracao";
            this.btnSubtracao.Size = new System.Drawing.Size(112, 34);
            this.btnSubtracao.TabIndex = 10;
            this.btnSubtracao.Text = "-";
            this.btnSubtracao.UseVisualStyleBackColor = true;
            this.btnSubtracao.Click += new System.EventHandler(this.btnSubtracao_Click);
            // 
            // btnNumero6
            // 
            this.btnNumero6.Location = new System.Drawing.Point(320, 164);
            this.btnNumero6.Name = "btnNumero6";
            this.btnNumero6.Size = new System.Drawing.Size(112, 34);
            this.btnNumero6.TabIndex = 9;
            this.btnNumero6.Text = "6";
            this.btnNumero6.UseVisualStyleBackColor = true;
            this.btnNumero6.Click += new System.EventHandler(this.btnNumero6_Click);
            // 
            // btnNumero5
            // 
            this.btnNumero5.Location = new System.Drawing.Point(176, 164);
            this.btnNumero5.Name = "btnNumero5";
            this.btnNumero5.Size = new System.Drawing.Size(112, 34);
            this.btnNumero5.TabIndex = 8;
            this.btnNumero5.Text = "5";
            this.btnNumero5.UseVisualStyleBackColor = true;
            this.btnNumero5.Click += new System.EventHandler(this.btnNumero5_Click);
            // 
            // btnNumero4
            // 
            this.btnNumero4.Location = new System.Drawing.Point(32, 164);
            this.btnNumero4.Name = "btnNumero4";
            this.btnNumero4.Size = new System.Drawing.Size(113, 34);
            this.btnNumero4.TabIndex = 7;
            this.btnNumero4.Text = "4";
            this.btnNumero4.UseVisualStyleBackColor = true;
            this.btnNumero4.Click += new System.EventHandler(this.btnNumero4_Click);
            // 
            // btnResultado
            // 
            this.btnResultado.Location = new System.Drawing.Point(597, 217);
            this.btnResultado.Name = "btnResultado";
            this.btnResultado.Size = new System.Drawing.Size(112, 34);
            this.btnResultado.TabIndex = 16;
            this.btnResultado.Text = "=";
            this.btnResultado.UseVisualStyleBackColor = true;
            this.btnResultado.Click += new System.EventHandler(this.btnResultado_Click);
            // 
            // btnMultiplicacao
            // 
            this.btnMultiplicacao.Location = new System.Drawing.Point(458, 217);
            this.btnMultiplicacao.Name = "btnMultiplicacao";
            this.btnMultiplicacao.Size = new System.Drawing.Size(112, 34);
            this.btnMultiplicacao.TabIndex = 15;
            this.btnMultiplicacao.Text = "*";
            this.btnMultiplicacao.UseVisualStyleBackColor = true;
            this.btnMultiplicacao.Click += new System.EventHandler(this.btnMultiplicacao_Click);
            // 
            // btnNumero3
            // 
            this.btnNumero3.Location = new System.Drawing.Point(320, 217);
            this.btnNumero3.Name = "btnNumero3";
            this.btnNumero3.Size = new System.Drawing.Size(112, 34);
            this.btnNumero3.TabIndex = 14;
            this.btnNumero3.Text = "3";
            this.btnNumero3.UseVisualStyleBackColor = true;
            this.btnNumero3.Click += new System.EventHandler(this.btnNumero3_Click);
            // 
            // btnNumero2
            // 
            this.btnNumero2.Location = new System.Drawing.Point(176, 217);
            this.btnNumero2.Name = "btnNumero2";
            this.btnNumero2.Size = new System.Drawing.Size(112, 34);
            this.btnNumero2.TabIndex = 13;
            this.btnNumero2.Text = "2";
            this.btnNumero2.UseVisualStyleBackColor = true;
            this.btnNumero2.Click += new System.EventHandler(this.btnNumero2_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(597, 274);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(112, 34);
            this.btnSair.TabIndex = 21;
            this.btnSair.Text = "Exit";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnDivisao
            // 
            this.btnDivisao.Location = new System.Drawing.Point(458, 274);
            this.btnDivisao.Name = "btnDivisao";
            this.btnDivisao.Size = new System.Drawing.Size(112, 34);
            this.btnDivisao.TabIndex = 20;
            this.btnDivisao.Text = "/";
            this.btnDivisao.UseVisualStyleBackColor = true;
            this.btnDivisao.Click += new System.EventHandler(this.btnDivisao_Click);
            // 
            // btnPonto
            // 
            this.btnPonto.Location = new System.Drawing.Point(320, 274);
            this.btnPonto.Name = "btnPonto";
            this.btnPonto.Size = new System.Drawing.Size(112, 34);
            this.btnPonto.TabIndex = 18;
            this.btnPonto.Text = ".";
            this.btnPonto.UseVisualStyleBackColor = true;
            this.btnPonto.Click += new System.EventHandler(this.btnPonto_Click);
            // 
            // btnNumero0
            // 
            this.btnNumero0.Location = new System.Drawing.Point(35, 274);
            this.btnNumero0.Name = "btnNumero0";
            this.btnNumero0.Size = new System.Drawing.Size(253, 34);
            this.btnNumero0.TabIndex = 17;
            this.btnNumero0.Text = "0";
            this.btnNumero0.UseVisualStyleBackColor = true;
            this.btnNumero0.Click += new System.EventHandler(this.btnNumero0_Click);
            // 
            // btnNumero1
            // 
            this.btnNumero1.Location = new System.Drawing.Point(35, 217);
            this.btnNumero1.Name = "btnNumero1";
            this.btnNumero1.Size = new System.Drawing.Size(112, 34);
            this.btnNumero1.TabIndex = 22;
            this.btnNumero1.Text = "1";
            this.btnNumero1.UseVisualStyleBackColor = true;
            this.btnNumero1.Click += new System.EventHandler(this.btnNumero1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 450);
            this.Controls.Add(this.btnNumero1);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnDivisao);
            this.Controls.Add(this.btnPonto);
            this.Controls.Add(this.btnNumero0);
            this.Controls.Add(this.btnResultado);
            this.Controls.Add(this.btnMultiplicacao);
            this.Controls.Add(this.btnNumero3);
            this.Controls.Add(this.btnNumero2);
            this.Controls.Add(this.btnExcluir);
            this.Controls.Add(this.btnSubtracao);
            this.Controls.Add(this.btnNumero6);
            this.Controls.Add(this.btnNumero5);
            this.Controls.Add(this.btnNumero4);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.btnNumero9);
            this.Controls.Add(this.btnNumero8);
            this.Controls.Add(this.btnNumero7);
            this.Controls.Add(this.lblOperacao);
            this.Controls.Add(this.txtResultado);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private TextBox txtResultado;
        private Label lblOperacao;
        private Button btnNumero7;
        private Button btnNumero8;
        private Button btnNumero9;
        private Button btnSoma;
        private Button btnLimpar;
        private Button btnExcluir;
        private Button btnSubtracao;
        private Button btnNumero6;
        private Button btnNumero5;
        private Button btnNumero4;
        private Button btnResultado;
        private Button btnMultiplicacao;
        private Button btnNumero3;
        private Button btnNumero2;
        private Button btnSair;
        private Button btnDivisao;
        private Button btnPonto;
        private Button btnNumero0;
        private Button btnNumero1;
    }
}