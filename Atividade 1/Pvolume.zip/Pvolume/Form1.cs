namespace Pvolume
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double raio, altura;

            if (Double.TryParse(txtRaio.Text, out raio) && Double.TryParse(txtAltura.Text, out altura))
            {
                if ((altura <= 0) || (raio <= 0))
                {
                    MessageBox.Show("Inserir valores maiores que 0!");
                    txtRaio.Focus();
                }
                else
                {
                    double volume;

                    volume = Math.PI * Math.Pow(raio, 2) * altura;
                    txtVolume.Text = volume.ToString("N2");
                }
            }
            else
            {
                MessageBox.Show("Valores inv�lidos!");
                txtRaio.Focus();
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

       
    }
}