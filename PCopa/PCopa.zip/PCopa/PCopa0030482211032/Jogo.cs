﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PCopa0030482211032
{
    class Jogo
    {
        public int Id { get; set; }
        public int EstadioId { get; set; }
        public int PaisId1 { get; set; }
        public int PaisId2 { get; set; }
        public DateTime Datahora { get; set; }

        public Char Grupo { get; set; }
        public string Observação;

        public DataTable Listar()
        {
            SqlDataAdapter daJogo;
            DataTable dtJogo = new DataTable();

            try
            {
                daJogo = new SqlDataAdapter("SELECT * FROM JOGO", frmPrincipal.conexao);
                daJogo.Fill(dtJogo);
                daJogo.FillSchema(dtJogo.schSource);

            }
            catch (Exception)
            {
                throw;
            }
                 return dtJogo;
        }


        public int Excluir()
        {

            int nReg = 0; try
            {
                SqlCommand mycommand;

                mycommand = newSqlCommand("DELETE FROM JOGO WHERE ID-@id", frmPrincipal.conexao);

                mycommand.Parameters.Add(newSqlParameter("@id", SqlDbType.Int));
                mycommand.Parameters["@id"].Value = Id;
                nReg = mycommand.ExecuteNonQuery();
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return nReg;
        }

        public int Salvar() 
        { 
            int nReg = 0; 

            try 
            { 
                SqlCommand mycommand; 
                int nReg; mycommand = newSqlCommand("INSERT INTO JOGO VALUES (@pais1," + "@pais2, @estadio, @datahora, @observacão)", frmPrincipal.conexao); 
                mycommand.Parameters.Add(newSqlParameter("@pais1", SqlDbType.Int));                
                mycommand.Parameters.Add(newSqlParameter("@pais2", SqlDbType.Int));
                mycommand.Parameters.Add(newSqlParameter("@estadio", SqlDbType.Int));
                mycommand.Parameters.Add(newSqlParameter("@datahora", SqlDbType.Date));
                mycommand.Parameters.Add(newSqlParameter("@observacão", SqlDbType.VarChar)); 

                mycommand.Parameters["@pais1"].Value = PaisId1; 
                mycommand.Parameters["@pais2"].Value = PaisId2;
                mycommand.Parameters["@estadio"].Value = EstadioId;
                mycommand.Parameters["@datahora"].Value = Datahora;
                mycommand.Parameters["@observacao"].Value = Observação; 

                nReg = mycommand.ExecuteNonQuery(); 
                
                if (nReg > 0) 
                { 
                    retorno = nReg; 
                } 
            } 
            catch (Exception ex) 
            { 
                throw ex; 
            } 
            return retorno; } 
    }
}
