﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PCopa0030482211032
{
    class Class1
    {
    }
}
