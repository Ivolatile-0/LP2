﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace PCopa0030482211032
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conexao;
 

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
        
        try
         { 
        // aqui a conexão vai depende da sua máquina da escola ou particular 
             conexao = new SqlConnection("Data Source=APOLO;Initial Catalog=LP2;User ID=bd2211032;PASSWORD=Ftf05Ferrago@"); 
        conexao.Open(); 
        } 
         catch (SqlException ex) 
        { 
        MessageBox.Show("Erro de banco de dados =/" + ex.Message); 
        } 
         catch (Exception ex) 
        { 
        MessageBox.Show("Outros Erros =/" + ex.Message); 
        } 
        }
    }
}
