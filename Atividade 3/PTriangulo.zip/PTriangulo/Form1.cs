namespace PTriangulo
{
    public partial class Form1 : Form
    {
        double Lado1, Lado2, Lado3;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Text = "";
            txtLado2.Text = "";
            txtLado3.Text = "";
            Lado1 = 0;
            Lado2 = 0;
            Lado3 = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLado1.Text, out Lado1) ||
                !double.TryParse(txtLado2.Text, out Lado2) ||
                !double.TryParse(txtLado3.Text, out Lado3))
            {
                MessageBox.Show("Inserir valores num�ricos!");
            }
            else
            {
                if (Lado1 < (Lado2 + Lado3) && Lado1 > Math.Abs(Lado2 - Lado3) &&
                    Lado2 < (Lado1 + Lado3) && Lado2 > Math.Abs(Lado1 - Lado3) &&
                    Lado3 < (Lado1 + Lado2) && Lado3 > Math.Abs(Lado1 - Lado2))
                {
                    if (Lado1 == Lado2 && Lado2 == Lado3)
                    {
                        MessageBox.Show("O tri�ngulo � equil�tero!");
                    }
                    else
                    {
                        if (Lado1 == Lado2 || Lado1 == Lado3 || Lado3 == Lado2)
                        {
                            MessageBox.Show("O tri�ngulo � is�celes!");
                        }
                        else
                        {
                            MessageBox.Show("O tri�ngulo � escaleno!");
                        }
                    }
                }
            }
        }
    }
}