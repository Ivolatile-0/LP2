namespace Atividade3IMC
{
    public partial class Form1 : Form
    {
        double AlturaAtual, PesoAtual, ResultadoImc;

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtImc.Text = "";
            txtAltura.Text = "";
            txtPeso.Text = "";
            AlturaAtual = 0;
            PesoAtual = 0;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if 
                (double.TryParse(txtAltura.Text, out AlturaAtual) &&
                double.TryParse(txtPeso.Text, out PesoAtual))
            {
                if ((AlturaAtual <= 0) || (PesoAtual <= 0))
                {
                    MessageBox.Show("Valores devem ser maiores que 0!", "ATEN��O!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                }

                else
                {
                    ResultadoImc = PesoAtual / (Math.Pow(AlturaAtual, 2));

                    ResultadoImc = Math.Round(ResultadoImc, 1);

                    txtImc.Text = ResultadoImc.ToString("N1");

                    if (ResultadoImc < 18.5)
                    {
                        MessageBox.Show("Magreza");
                    }
                    else if (ResultadoImc <= 24.9)
                    {
                        MessageBox.Show("Normal");
                    }
                    else if (ResultadoImc <= 29.9)
                    {
                        MessageBox.Show("Sobrepeso");
                    }
                    else if (ResultadoImc <= 39.9)
                    {
                        MessageBox.Show("Obesidade");
                    }  
                    else
                    {
                        MessageBox.Show("Obesidade Grave");
                    }
                        
                }
            }
            else 
            {
                MessageBox.Show("Valores Inv�lidos");
            }    
        }
    }
}