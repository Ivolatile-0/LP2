﻿namespace Pclasses
{
    partial class frmMensalista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtnome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtDataEntrada = new System.Windows.Forms.TextBox();
            this.lbMatricula = new System.Windows.Forms.Label();
            this.lbNome = new System.Windows.Forms.Label();
            this.lbSalario = new System.Windows.Forms.Label();
            this.lbDataEntrada = new System.Windows.Forms.Label();
            this.btInstanciarMensalista = new System.Windows.Forms.Button();
            this.btInstanciarMensalistaPassado = new System.Windows.Forms.Button();
            this.gp = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNão = new System.Windows.Forms.RadioButton();
            this.gp.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtMatricula
            // 
            this.txtMatricula.Location = new System.Drawing.Point(198, 44);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 20);
            this.txtMatricula.TabIndex = 0;
            // 
            // txtnome
            // 
            this.txtnome.Location = new System.Drawing.Point(198, 81);
            this.txtnome.Name = "txtnome";
            this.txtnome.Size = new System.Drawing.Size(100, 20);
            this.txtnome.TabIndex = 1;
            // 
            // txtSalario
            // 
            this.txtSalario.Location = new System.Drawing.Point(198, 114);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(100, 20);
            this.txtSalario.TabIndex = 2;
            // 
            // txtDataEntrada
            // 
            this.txtDataEntrada.Location = new System.Drawing.Point(198, 148);
            this.txtDataEntrada.Name = "txtDataEntrada";
            this.txtDataEntrada.Size = new System.Drawing.Size(100, 20);
            this.txtDataEntrada.TabIndex = 3;
            // 
            // lbMatricula
            // 
            this.lbMatricula.AutoSize = true;
            this.lbMatricula.Location = new System.Drawing.Point(48, 47);
            this.lbMatricula.Name = "lbMatricula";
            this.lbMatricula.Size = new System.Drawing.Size(52, 13);
            this.lbMatricula.TabIndex = 4;
            this.lbMatricula.Text = "Matrícula";
            // 
            // lbNome
            // 
            this.lbNome.AutoSize = true;
            this.lbNome.Location = new System.Drawing.Point(48, 84);
            this.lbNome.Name = "lbNome";
            this.lbNome.Size = new System.Drawing.Size(35, 13);
            this.lbNome.TabIndex = 5;
            this.lbNome.Text = "Nome";
            // 
            // lbSalario
            // 
            this.lbSalario.AutoSize = true;
            this.lbSalario.Location = new System.Drawing.Point(48, 117);
            this.lbSalario.Name = "lbSalario";
            this.lbSalario.Size = new System.Drawing.Size(76, 13);
            this.lbSalario.TabIndex = 6;
            this.lbSalario.Text = "Salário Mensal";
            // 
            // lbDataEntrada
            // 
            this.lbDataEntrada.AutoSize = true;
            this.lbDataEntrada.Location = new System.Drawing.Point(48, 151);
            this.lbDataEntrada.Name = "lbDataEntrada";
            this.lbDataEntrada.Size = new System.Drawing.Size(144, 13);
            this.lbDataEntrada.TabIndex = 7;
            this.lbDataEntrada.Text = "Data de Entrada na Empresa";
            // 
            // btInstanciarMensalista
            // 
            this.btInstanciarMensalista.Location = new System.Drawing.Point(23, 214);
            this.btInstanciarMensalista.Name = "btInstanciarMensalista";
            this.btInstanciarMensalista.Size = new System.Drawing.Size(194, 78);
            this.btInstanciarMensalista.TabIndex = 8;
            this.btInstanciarMensalista.Text = "Instanciar Mensalista";
            this.btInstanciarMensalista.UseVisualStyleBackColor = true;
            // 
            // btInstanciarMensalistaPassado
            // 
            this.btInstanciarMensalistaPassado.Location = new System.Drawing.Point(274, 214);
            this.btInstanciarMensalistaPassado.Name = "btInstanciarMensalistaPassado";
            this.btInstanciarMensalistaPassado.Size = new System.Drawing.Size(202, 78);
            this.btInstanciarMensalistaPassado.TabIndex = 9;
            this.btInstanciarMensalistaPassado.Text = "Instanciar Mensalista passado parâmetros";
            this.btInstanciarMensalistaPassado.UseVisualStyleBackColor = true;
            // 
            // gp
            // 
            this.gp.Controls.Add(this.rbtnNão);
            this.gp.Controls.Add(this.rbtnSim);
            this.gp.Location = new System.Drawing.Point(429, 47);
            this.gp.Name = "gp";
            this.gp.Size = new System.Drawing.Size(200, 100);
            this.gp.TabIndex = 10;
            this.gp.TabStop = false;
            this.gp.Text = "Trabalha em Home Oficce";
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Location = new System.Drawing.Point(0, 43);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(42, 17);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "Sim";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNão
            // 
            this.rbtnNão.AutoSize = true;
            this.rbtnNão.Location = new System.Drawing.Point(0, 66);
            this.rbtnNão.Name = "rbtnNão";
            this.rbtnNão.Size = new System.Drawing.Size(45, 17);
            this.rbtnNão.TabIndex = 1;
            this.rbtnNão.TabStop = true;
            this.rbtnNão.Text = "Não";
            this.rbtnNão.UseVisualStyleBackColor = true;
            // 
            // frmMensalista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(665, 326);
            this.Controls.Add(this.gp);
            this.Controls.Add(this.btInstanciarMensalistaPassado);
            this.Controls.Add(this.btInstanciarMensalista);
            this.Controls.Add(this.lbDataEntrada);
            this.Controls.Add(this.lbSalario);
            this.Controls.Add(this.lbNome);
            this.Controls.Add(this.lbMatricula);
            this.Controls.Add(this.txtDataEntrada);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtnome);
            this.Controls.Add(this.txtMatricula);
            this.Name = "frmMensalista";
            this.Text = "frmMensalista";
            this.Load += new System.EventHandler(this.frmMensalista_Load);
            this.gp.ResumeLayout(false);
            this.gp.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtnome;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtDataEntrada;
        private System.Windows.Forms.Label lbMatricula;
        private System.Windows.Forms.Label lbNome;
        private System.Windows.Forms.Label lbSalario;
        private System.Windows.Forms.Label lbDataEntrada;
        private System.Windows.Forms.Button btInstanciarMensalista;
        private System.Windows.Forms.Button btInstanciarMensalistaPassado;
        private System.Windows.Forms.GroupBox gp;
        private System.Windows.Forms.RadioButton rbtnNão;
        private System.Windows.Forms.RadioButton rbtnSim;
    }
}