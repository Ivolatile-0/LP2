﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pclasses
{
    abstract class Empregado
    {
        private int matricula;//propriedade
        private string nomeEmpregado;
        private DateTime dataEntrada;
        private char homeOffice;

        public int Matricula//propriedade
        {
            get { return matricula; }
            set { matricula = value;}
        }
        public string NomeEmpregado
        {
            get { return nomeEmpregado; }
            set { nomeEmpregado = value; }
        }

        public DateTime DataEntrada
        {
            get { return dataEntrada;}
            set { dataEntrada = value;}
        }
        public char HomeOffice
        {
            get { return homeOffice;}
            set { homeOffice = value; }
        }

        public String VerificaHome()
        {
            if (homeOffice == 'S')
                return "Empregado trabalha em home office";
            else
                return "Empregado NÃO trabalha em home office";
        }
        //metodo sao ações/comportamentos
        //virtual --> pode ser sobreescrito

        public virtual int TempoTrabalho()
        {

            //representa um intervalo de tempo
            TimeSpan span = DateTime.Today.Subtract(DataEntrada);
            return (span.Days);
        }
        //deve ser implementado
        //derived casses must implementament this
        public abstract double SalarioBruto(); //nâo preciso implementar

        public Empregado() //construtor --> NEW
        {

        }
     }
}
