﻿namespace WindowsFormsApplication1
{
    partial class frmHorista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMatricula = new System.Windows.Forms.Label();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalario = new System.Windows.Forms.Label();
            this.lblHoras = new System.Windows.Forms.Label();
            this.lblFaltas = new System.Windows.Forms.Label();
            this.lblData = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalario = new System.Windows.Forms.TextBox();
            this.txtHoras = new System.Windows.Forms.TextBox();
            this.txtFaltas = new System.Windows.Forms.TextBox();
            this.txtData = new System.Windows.Forms.TextBox();
            this.gbxHomeOffice = new System.Windows.Forms.GroupBox();
            this.rbtnSim = new System.Windows.Forms.RadioButton();
            this.rbtnNao = new System.Windows.Forms.RadioButton();
            this.btnInstanciar = new System.Windows.Forms.Button();
            this.gbxHomeOffice.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblMatricula.Location = new System.Drawing.Point(62, 73);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(105, 27);
            this.lblMatricula.TabIndex = 0;
            this.lblMatricula.Text = "Matricula";
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblNome.Location = new System.Drawing.Point(62, 131);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(70, 27);
            this.lblNome.TabIndex = 1;
            this.lblNome.Text = "Nome";
            // 
            // lblSalario
            // 
            this.lblSalario.AutoSize = true;
            this.lblSalario.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblSalario.Location = new System.Drawing.Point(62, 195);
            this.lblSalario.Name = "lblSalario";
            this.lblSalario.Size = new System.Drawing.Size(170, 27);
            this.lblSalario.TabIndex = 2;
            this.lblSalario.Text = "Salario por Hora";
            // 
            // lblHoras
            // 
            this.lblHoras.AutoSize = true;
            this.lblHoras.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblHoras.Location = new System.Drawing.Point(62, 259);
            this.lblHoras.Name = "lblHoras";
            this.lblHoras.Size = new System.Drawing.Size(182, 27);
            this.lblHoras.TabIndex = 3;
            this.lblHoras.Text = "Número de Horas";
            // 
            // lblFaltas
            // 
            this.lblFaltas.AutoSize = true;
            this.lblFaltas.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblFaltas.Location = new System.Drawing.Point(62, 325);
            this.lblFaltas.Name = "lblFaltas";
            this.lblFaltas.Size = new System.Drawing.Size(110, 27);
            this.lblFaltas.TabIndex = 4;
            this.lblFaltas.Text = "Ausências";
            // 
            // lblData
            // 
            this.lblData.AutoSize = true;
            this.lblData.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.lblData.Location = new System.Drawing.Point(62, 390);
            this.lblData.Name = "lblData";
            this.lblData.Size = new System.Drawing.Size(186, 27);
            this.lblData.TabIndex = 5;
            this.lblData.Text = "Data de Admissão";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtMatricula.Location = new System.Drawing.Point(308, 70);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(264, 35);
            this.txtMatricula.TabIndex = 6;
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtNome.Location = new System.Drawing.Point(308, 131);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(264, 35);
            this.txtNome.TabIndex = 7;
            // 
            // txtSalario
            // 
            this.txtSalario.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtSalario.Location = new System.Drawing.Point(308, 195);
            this.txtSalario.Name = "txtSalario";
            this.txtSalario.Size = new System.Drawing.Size(264, 35);
            this.txtSalario.TabIndex = 8;
            // 
            // txtHoras
            // 
            this.txtHoras.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtHoras.Location = new System.Drawing.Point(308, 259);
            this.txtHoras.Name = "txtHoras";
            this.txtHoras.Size = new System.Drawing.Size(264, 35);
            this.txtHoras.TabIndex = 9;
            // 
            // txtFaltas
            // 
            this.txtFaltas.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtFaltas.Location = new System.Drawing.Point(308, 325);
            this.txtFaltas.Name = "txtFaltas";
            this.txtFaltas.Size = new System.Drawing.Size(264, 35);
            this.txtFaltas.TabIndex = 10;
            // 
            // txtData
            // 
            this.txtData.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.txtData.Location = new System.Drawing.Point(308, 390);
            this.txtData.Name = "txtData";
            this.txtData.Size = new System.Drawing.Size(264, 35);
            this.txtData.TabIndex = 11;
            // 
            // gbxHomeOffice
            // 
            this.gbxHomeOffice.Controls.Add(this.rbtnNao);
            this.gbxHomeOffice.Controls.Add(this.rbtnSim);
            this.gbxHomeOffice.Font = new System.Drawing.Font("Times New Roman", 14F);
            this.gbxHomeOffice.Location = new System.Drawing.Point(752, 73);
            this.gbxHomeOffice.Name = "gbxHomeOffice";
            this.gbxHomeOffice.Size = new System.Drawing.Size(351, 106);
            this.gbxHomeOffice.TabIndex = 12;
            this.gbxHomeOffice.TabStop = false;
            this.gbxHomeOffice.Text = "Trabalha em Home Office?";
            // 
            // rbtnSim
            // 
            this.rbtnSim.AutoSize = true;
            this.rbtnSim.Checked = true;
            this.rbtnSim.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.rbtnSim.Location = new System.Drawing.Point(17, 36);
            this.rbtnSim.Name = "rbtnSim";
            this.rbtnSim.Size = new System.Drawing.Size(78, 31);
            this.rbtnSim.TabIndex = 0;
            this.rbtnSim.TabStop = true;
            this.rbtnSim.Text = "SIM";
            this.rbtnSim.UseVisualStyleBackColor = true;
            // 
            // rbtnNao
            // 
            this.rbtnNao.AutoSize = true;
            this.rbtnNao.Font = new System.Drawing.Font("Times New Roman", 12F);
            this.rbtnNao.Location = new System.Drawing.Point(159, 36);
            this.rbtnNao.Name = "rbtnNao";
            this.rbtnNao.Size = new System.Drawing.Size(88, 31);
            this.rbtnNao.TabIndex = 1;
            this.rbtnNao.Text = "NÃO";
            this.rbtnNao.UseVisualStyleBackColor = true;
            // 
            // btnInstanciar
            // 
            this.btnInstanciar.Font = new System.Drawing.Font("Times New Roman", 20F);
            this.btnInstanciar.Location = new System.Drawing.Point(752, 234);
            this.btnInstanciar.Name = "btnInstanciar";
            this.btnInstanciar.Size = new System.Drawing.Size(351, 191);
            this.btnInstanciar.TabIndex = 13;
            this.btnInstanciar.Text = "Instanciar Horista";
            this.btnInstanciar.UseVisualStyleBackColor = true;
            this.btnInstanciar.Click += new System.EventHandler(this.btnInstanciar_Click);
            // 
            // frmHorista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.ClientSize = new System.Drawing.Size(1333, 471);
            this.Controls.Add(this.btnInstanciar);
            this.Controls.Add(this.gbxHomeOffice);
            this.Controls.Add(this.txtData);
            this.Controls.Add(this.txtFaltas);
            this.Controls.Add(this.txtHoras);
            this.Controls.Add(this.txtSalario);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblData);
            this.Controls.Add(this.lblFaltas);
            this.Controls.Add(this.lblHoras);
            this.Controls.Add(this.lblSalario);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.lblMatricula);
            this.Name = "frmHorista";
            this.Text = "frmHorista";
            this.gbxHomeOffice.ResumeLayout(false);
            this.gbxHomeOffice.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalario;
        private System.Windows.Forms.Label lblHoras;
        private System.Windows.Forms.Label lblFaltas;
        private System.Windows.Forms.Label lblData;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalario;
        private System.Windows.Forms.TextBox txtHoras;
        private System.Windows.Forms.TextBox txtFaltas;
        private System.Windows.Forms.TextBox txtData;
        private System.Windows.Forms.GroupBox gbxHomeOffice;
        private System.Windows.Forms.RadioButton rbtnNao;
        private System.Windows.Forms.RadioButton rbtnSim;
        private System.Windows.Forms.Button btnInstanciar;
    }
}