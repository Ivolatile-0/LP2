﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    class Mensalista : Empregado //classe filha da empregado//
    {
        //prop + 2 TAB's: public int MyProperty { get; set; }//
        public Double SalarioMensal { get; set; }

        public override double SalarioBruto()//com o virtual, sobrescreve o código//
        {
            return SalarioMensal;
        }
    }
}
